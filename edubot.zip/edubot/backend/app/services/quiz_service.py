"""
Quiz-generation service.

The fine-tuned T5 checkpoint (`valhalla/t5-base-qg-hl`) is a *conditional*
question generator: it takes a context where the **answer span is wrapped
in `<hl> ... <hl>` tags** and produces a question whose answer is that span.

So for *open-ended* quiz generation from a passage we need to:

  1. Split the passage into sentences.
  2. For each sentence, mine a few promising answer candidates
     (noun phrases, numbers) using NLTK.
  3. Build the highlighted input for each (sentence, candidate) pair.
  4. Batch them through T5 and decode.
  5. De-duplicate generated questions and stop at `num_questions`.

This produces meaningfully different questions per passage without
needing the user to manually mark the answer.
"""

from __future__ import annotations

import logging
import time
from typing import List

import torch

from app.models import ModelManager
from app.schemas import QuizItem, QuizResponse
from app.utils import (
    clean_text,
    extract_answer_candidates,
    split_sentences,
)

logger = logging.getLogger(__name__)

# Caps mirror the training-time hyper-parameters.
_INPUT_MAX = 512
_OUTPUT_MAX = 64
_BATCH_SIZE = 8       # T5-base on a 4-6 GB GPU handles this comfortably


def _build_hl_input(sentence: str, answer: str) -> str | None:
    """Wrap `answer` in <hl> tags inside `sentence`. Returns None if not found."""
    idx = sentence.lower().find(answer.lower())
    if idx == -1:
        return None
    before = sentence[:idx]
    match = sentence[idx : idx + len(answer)]
    after = sentence[idx + len(answer):]
    return f"generate question: {before}<hl> {match} <hl>{after}"


def generate_quiz(text: str, num_questions: int = 5) -> QuizResponse:
    """Generate `num_questions` quiz items from `text`."""
    t0 = time.perf_counter()

    mgr = ModelManager.get_instance()
    tokenizer, model, device = mgr.quiz_tokenizer, mgr.quiz_model, mgr.device

    text = clean_text(text)
    sentences = split_sentences(text)

    # ── Step 1+2: build (sentence, candidate) pairs ──────────────────
    pairs: List[tuple[str, str, str]] = []   # (input_str, answer, sentence)
    # We give ourselves headroom: ask for ~2x candidates and de-dup later.
    target_candidates = max(num_questions * 2, num_questions + 3)

    for sent in sentences:
        if len(sent.split()) < 5:           # skip trivial sentences
            continue
        for cand in extract_answer_candidates(sent, top_n=3):
            inp = _build_hl_input(sent, cand)
            if inp is not None:
                pairs.append((inp, cand, sent))
        if len(pairs) >= target_candidates:
            break

    if not pairs:
        latency_ms = int((time.perf_counter() - t0) * 1000)
        logger.warning("Quiz: no answer candidates found in input.")
        return QuizResponse(
            questions=[],
            requested=num_questions,
            generated=0,
            latency_ms=latency_ms,
        )

    # ── Step 3+4: batched T5 generation ──────────────────────────────
    items: List[QuizItem] = []
    seen_questions: set[str] = set()

    for batch_start in range(0, len(pairs), _BATCH_SIZE):
        batch = pairs[batch_start : batch_start + _BATCH_SIZE]
        inputs = [p[0] for p in batch]

        enc = tokenizer(
            inputs,
            return_tensors="pt",
            truncation=True,
            max_length=_INPUT_MAX,
            padding=True,
        ).to(device)

        with torch.no_grad():
            out = model.generate(
                **enc,
                max_length=_OUTPUT_MAX,
                num_beams=4,
                no_repeat_ngram_size=2,
                early_stopping=True,
            )

        decoded = tokenizer.batch_decode(out, skip_special_tokens=True)

        for question, (_, answer, sentence) in zip(decoded, batch):
            q = clean_text(question)
            # T5 sometimes emits "question: ...." — strip the prefix.
            if q.lower().startswith("question:"):
                q = q[len("question:"):].strip()
            # Ensure it ends with a "?"
            if q and not q.endswith("?"):
                q = q.rstrip(".!") + "?"
            # Make the first letter uppercase
            if q:
                q = q[0].upper() + q[1:]

            key = q.lower()
            if not q or key in seen_questions:
                continue
            seen_questions.add(key)

            items.append(QuizItem(question=q, answer=answer, context=sentence))
            if len(items) >= num_questions:
                break

        if len(items) >= num_questions:
            break

    latency_ms = int((time.perf_counter() - t0) * 1000)
    logger.info(
        "QUIZ → generated %d/%d questions from %d candidates in %dms",
        len(items), num_questions, len(pairs), latency_ms,
    )

    return QuizResponse(
        questions=items,
        requested=num_questions,
        generated=len(items),
        latency_ms=latency_ms,
    )
