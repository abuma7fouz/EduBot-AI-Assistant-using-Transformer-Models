"""
EdU BOT — FastAPI entry point.

Run with:

    cd backend
    uvicorn app.main:app --reload --port 8000

Once running, browse http://localhost:8000/docs for the interactive
OpenAPI playground.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app import __team__, __version__
from app.config import settings
from app.models import ModelManager
from app.routers import qa, quiz, summarize
from app.schemas import HealthResponse

# ── Logging ───────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("edubot")


# ── Lifespan: load models on startup ─────────────────────────────────
@asynccontextmanager
async def lifespan(_: FastAPI):
    logger.info("🎓 EdU BOT — Team %s — booting up…", __team__)
    try:
        ModelManager.get_instance()                # triggers model loading
    except Exception:                              # noqa: BLE001
        logger.exception(
            "Failed to load models. Check the *_MODEL_PATH values in your .env "
            "file or environment. The server will still start — health checks "
            "will report the failure."
        )
    yield
    logger.info("👋 EdU BOT shutting down.")


# ── App ──────────────────────────────────────────────────────────────
app = FastAPI(
    title="EdU BOT API",
    description=(
        "Educational AI assistant by **TEAM ELMOLOK**.\n\n"
        "Three fine-tuned transformer models power the three endpoints:\n"
        "* `/api/qa`        — BERT (extractive QA)\n"
        "* `/api/summarize` — DistilBART (abstractive summarization)\n"
        "* `/api/quiz`      — T5 (question generation with `<hl>` answer tags)\n"
    ),
    version=__version__,
    lifespan=lifespan,
)


# ── CORS ─────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


# ── Routers ──────────────────────────────────────────────────────────
app.include_router(qa.router,        prefix="/api/qa",        tags=["Question Answering"])
app.include_router(summarize.router, prefix="/api/summarize", tags=["Summarization"])
app.include_router(quiz.router,      prefix="/api/quiz",      tags=["Quiz Generation"])


# ── Meta endpoints ───────────────────────────────────────────────────
@app.get("/", response_model=HealthResponse, tags=["Meta"])
async def root() -> HealthResponse:
    try:
        models = ModelManager.get_instance().status()
    except Exception as e:                                   # noqa: BLE001
        models = {"error": str(e)}
    return HealthResponse(
        status="running",
        version=__version__,
        team=__team__,
        models=models,
    )


@app.get("/health", response_model=HealthResponse, tags=["Meta"])
async def health() -> HealthResponse:
    return await root()
