"""POST /api/quiz  →  generate quiz questions from educational content."""

import logging

from fastapi import APIRouter, HTTPException

from app.schemas import QuizRequest, QuizResponse
from app.services import generate_quiz

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("", response_model=QuizResponse, summary="Generate a quiz from a passage")
async def post_quiz(req: QuizRequest) -> QuizResponse:
    try:
        return generate_quiz(req.text, req.num_questions)
    except Exception as e:                                   # noqa: BLE001
        logger.exception("Quiz generation failed")
        raise HTTPException(
            status_code=500,
            detail=f"Quiz inference failed: {e}",
        )
