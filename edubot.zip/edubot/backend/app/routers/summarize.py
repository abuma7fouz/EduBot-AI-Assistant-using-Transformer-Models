"""POST /api/summarize  →  abstractive text summarization."""

import logging

from fastapi import APIRouter, HTTPException

from app.schemas import SummarizeRequest, SummarizeResponse
from app.services import summarize_text

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("", response_model=SummarizeResponse, summary="Summarize a long passage")
async def post_summarize(req: SummarizeRequest) -> SummarizeResponse:
    if req.min_length >= req.max_length:
        raise HTTPException(
            status_code=422,
            detail="min_length must be smaller than max_length.",
        )
    try:
        return summarize_text(req.text, req.max_length, req.min_length)
    except Exception as e:                                   # noqa: BLE001
        logger.exception("Summarization failed")
        raise HTTPException(
            status_code=500,
            detail=f"Summarization inference failed: {e}",
        )
