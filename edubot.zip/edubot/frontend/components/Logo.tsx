import Link from 'next/link';

import { cn } from '@/lib/utils';

interface LogoProps {
  collapsed?: boolean;
  className?: string;
}

/**
 * Brand mark: a small geometric monogram + serif wordmark.
 * No external image — pure SVG so it scales and themes correctly.
 */
export function Logo({ collapsed = false, className }: LogoProps) {
  return (
    <Link href="/" className={cn('flex items-center gap-2.5 group', className)}>
      <span
        aria-hidden
        className="relative grid place-items-center w-9 h-9 rounded-xl
                   bg-gradient-to-br from-accent to-accent-soft
                   shadow-[0_2px_12px_-2px_rgb(var(--accent)/0.5)]
                   transition-transform duration-300 group-hover:scale-105"
      >
        <svg
          viewBox="0 0 24 24"
          className="w-5 h-5 text-bg"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          {/* Stylized graduation cap */}
          <path d="M3 9l9-5 9 5-9 5-9-5z" />
          <path d="M6 11v4c2 2 10 2 12 0v-4" />
        </svg>
      </span>
      {!collapsed && (
        <div className="flex flex-col leading-none">
          <span className="font-display text-[22px] tracking-tight">
            EdU <span className="italic text-accent">BOT</span>
          </span>
          <span className="text-[10px] uppercase tracking-[0.18em] text-muted mt-0.5">
            Team Elmolok
          </span>
        </div>
      )}
    </Link>
  );
}
