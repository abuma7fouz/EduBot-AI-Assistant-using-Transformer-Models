"""POST /api/qa  →  extractive question answering."""

import logging

from fastapi import APIRouter, HTTPException

from app.schemas import QARequest, QAResponse
from app.services import answer_question

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("", response_model=QAResponse, summary="Answer a question from a passage")
async def post_qa(req: QARequest) -> QAResponse:
    try:
        return answer_question(req.question, req.context)
    except Exception as e:                                   # noqa: BLE001
        logger.exception("QA failed")
        raise HTTPException(status_code=500, detail=f"QA inference failed: {e}")
