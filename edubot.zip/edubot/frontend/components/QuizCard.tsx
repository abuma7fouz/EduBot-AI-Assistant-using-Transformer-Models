'use client';

import { ChevronDown, Eye, EyeOff } from 'lucide-react';
import { useState } from 'react';

import { CopyButton } from './CopyButton';
import type { QuizItem } from '@/lib/api';
import { cn } from '@/lib/utils';

interface Props {
  index: number;
  total: number;
  item: QuizItem;
}

/**
 * Single quiz question card.
 *
 * • Question is shown by default (in serif so it reads like a textbook).
 * • The answer is hidden behind a "Reveal" button — encourages active
 *   recall, which is the whole point of an educational tool.
 * • The originating sentence is shown in a collapsed details section.
 */
export function QuizCard({ index, total, item }: Props) {
  const [revealed, setRevealed] = useState(false);
  const [expanded, setExpanded] = useState(false);

  return (
    <article
      className="surface-card rounded-3xl p-6 md:p-7 animate-fade-in-up
                 shadow-[0_1px_3px_rgb(0_0_0_/_0.02),0_8px_24px_-6px_rgb(0_0_0_/_0.06)]
                 transition-all duration-300 hover:shadow-[0_2px_4px_rgb(0_0_0_/_0.03),0_16px_32px_-8px_rgb(0_0_0_/_0.10)]"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      {/* Header */}
      <header className="flex items-center justify-between mb-4">
        <span className="inline-flex items-center gap-2">
          <span
            className="grid place-items-center w-7 h-7 rounded-lg
                       bg-accent/10 text-accent font-mono text-xs font-semibold"
          >
            {String(index + 1).padStart(2, '0')}
          </span>
          <span className="text-[11px] uppercase tracking-[0.16em] text-muted">
            Question {index + 1} of {total}
          </span>
        </span>
        <CopyButton text={`Q: ${item.question}\nA: ${item.answer}`} />
      </header>

      {/* Question */}
      <h3 className="font-display text-[22px] md:text-[24px] leading-snug text-fg mb-5">
        {item.question}
      </h3>

      {/* Answer (hidden by default) */}
      <button
        onClick={() => setRevealed((r) => !r)}
        aria-expanded={revealed}
        className={cn(
          'group w-full flex items-center justify-between gap-3',
          'rounded-2xl px-4 py-3 text-left transition-all duration-200',
          revealed
            ? 'bg-gold/8 border border-gold/30'
            : 'bg-elevated border border-border hover:border-gold/40',
        )}
      >
        <div className="flex items-center gap-3 min-w-0">
          <span
            className={cn(
              'shrink-0 grid place-items-center w-6 h-6 rounded-md transition-colors',
              revealed ? 'bg-gold/20 text-gold' : 'bg-surface text-muted',
            )}
          >
            {revealed ? <Eye size={13} /> : <EyeOff size={13} />}
          </span>
          {revealed ? (
            <span className="font-mono text-[14px] text-fg truncate">
              {item.answer}
            </span>
          ) : (
            <span className="text-[13px] text-muted">
              Tap to reveal the answer
            </span>
          )}
        </div>
        <span className="text-[11px] uppercase tracking-wider text-muted font-medium shrink-0">
          {revealed ? 'Hide' : 'Reveal'}
        </span>
      </button>

      {/* Source sentence (collapsible) */}
      <button
        onClick={() => setExpanded((e) => !e)}
        className="mt-4 inline-flex items-center gap-1.5 text-[11px] uppercase
                   tracking-[0.14em] text-muted hover:text-fg transition-colors"
        aria-expanded={expanded}
      >
        <ChevronDown
          size={12}
          className={cn('transition-transform', expanded && 'rotate-180')}
        />
        Source sentence
      </button>
      <div
        className={cn(
          'grid transition-[grid-template-rows] duration-300',
          expanded ? 'grid-rows-[1fr] mt-2' : 'grid-rows-[0fr]',
        )}
      >
        <div className="overflow-hidden">
          <p className="text-[13px] leading-relaxed text-muted italic border-l-2 border-border pl-3">
            {item.context}
          </p>
        </div>
      </div>
    </article>
  );
}
