'use client';

import {
  AlertCircle,
  Clock,
  Loader2,
  Sparkles,
  Wand2,
} from 'lucide-react';
import { FormEvent, useState } from 'react';

import { EmptyState } from '@/components/EmptyState';
import { LoadingIndicator } from '@/components/LoadingIndicator';
import { QuizCard } from '@/components/QuizCard';
import { api, type APIError, type QuizResponse } from '@/lib/api';
import { history } from '@/lib/store';
import { truncate } from '@/lib/utils';

const DEMO =
  "Photosynthesis is the process by which green plants and certain other organisms transform " +
  "light energy into chemical energy. During photosynthesis in plants, light energy is captured " +
  "and used to convert water, carbon dioxide, and minerals into oxygen and energy-rich organic " +
  "compounds. The process occurs primarily in the chloroplasts of plant cells, which contain " +
  "the green pigment chlorophyll. The overall chemical equation for photosynthesis can be " +
  "summarised as: six molecules of carbon dioxide plus six molecules of water, in the presence " +
  "of light energy, produce one molecule of glucose and six molecules of oxygen. Photosynthesis " +
  "is essential for the existence of the vast majority of life on Earth, because it provides the " +
  "oxygen we breathe and forms the base of nearly every food chain.";

export default function QuizPage() {
  const [text, setText] = useState('');
  const [numQuestions, setNumQuestions] = useState(5);

  const [result, setResult] = useState<QuizResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const tooShort = words < 30;

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (tooShort) {
      setError('Please paste at least 30 words of educational content.');
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await api.quiz(text, numQuestions);
      setResult(res);
      if (res.questions.length > 0) {
        history.add({
          feature: 'quiz',
          title: `${res.generated} questions · ${truncate(text, 60)}`,
          data: { text, ...res },
        });
      }
    } catch (err) {
      setError((err as APIError).detail || 'Quiz generation failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-full">
      <div className="max-w-3xl mx-auto px-6 md:px-10 py-10 md:py-14">
        {/* ── Page header ──────────────────────────────────── */}
        <header className="mb-10 animate-fade-in">
          <div className="flex items-center gap-3 mb-3">
            <span className="grid place-items-center w-10 h-10 rounded-xl
                             bg-emerald-400/10 text-emerald-400">
              <Sparkles size={18} />
            </span>
            <div>
              <h1 className="font-display text-3xl tracking-tight">Quiz Generation</h1>
              <p className="text-xs text-muted">
                Powered by fine-tuned <span className="font-mono">T5-base-qg-hl</span> ·
                generative
              </p>
            </div>
          </div>
          <p className="text-[15px] text-muted leading-relaxed max-w-2xl">
            Drop in lecture notes or any educational passage and EdU BOT will mine
            answer-worthy phrases, then ask the T5 model to write a question for each.
            Reveal the answers when you're ready — perfect for active recall.
          </p>
        </header>

        {/* ── Form ──────────────────────────────────────────── */}
        <form onSubmit={onSubmit} className="space-y-5 animate-fade-in-up">
          <div>
            <label className="flex items-center justify-between text-[11px] uppercase
                              tracking-[0.16em] text-muted mb-2">
              <span>Educational content</span>
              <span className="font-mono">{words} words</span>
            </label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste a passage you want to be quizzed on…"
              className="input-field min-h-[220px] resize-y leading-relaxed"
              rows={10}
            />
            <div className="mt-2 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => setText(DEMO)}
                className="text-[12px] text-accent hover:underline"
              >
                Use demo passage
              </button>
              {text && (
                <button
                  type="button"
                  onClick={() => setText('')}
                  className="text-[12px] text-muted hover:text-fg"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* ── Number of questions ───────────────────────── */}
          <div className="surface-card rounded-2xl p-5">
            <div className="flex items-baseline justify-between mb-3">
              <span className="text-[11px] uppercase tracking-[0.16em] text-muted">
                Number of questions
              </span>
              <span className="font-mono text-lg text-fg tabular-nums">
                {numQuestions}
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={15}
              step={1}
              value={numQuestions}
              onChange={(e) => setNumQuestions(Number(e.target.value))}
              className="w-full accent-accent"
            />
            <div className="mt-1 flex justify-between text-[10px] text-muted font-mono">
              <span>1</span>
              <span>15</span>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3">
            <button
              type="submit"
              disabled={loading || tooShort}
              className="btn-primary"
            >
              {loading ? (
                <>
                  <Loader2 size={15} className="animate-spin" />
                  Generating…
                </>
              ) : (
                <>
                  <Wand2 size={15} />
                  Generate quiz
                </>
              )}
            </button>
          </div>
        </form>

        {/* ── Output ────────────────────────────────────────── */}
        <section className="mt-10 space-y-4" aria-live="polite">
          {error && (
            <div className="flex items-start gap-3 text-[14px]
                            rounded-2xl border border-red-500/30 bg-red-500/5
                            text-red-400 px-4 py-3 animate-fade-in">
              <AlertCircle size={16} className="shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {loading && (
            <>
              <LoadingIndicator
                variant="dots"
                label="Mining answer candidates and generating questions"
              />
              <LoadingIndicator variant="skeleton" />
              <LoadingIndicator variant="skeleton" />
            </>
          )}

          {!loading && !result && !error && (
            <EmptyState
              icon={Sparkles}
              title="No quiz yet"
              description="Paste a passage above and hit Generate. EdU BOT will produce question cards you can reveal one at a time."
            />
          )}

          {result && result.questions.length === 0 && !loading && (
            <EmptyState
              icon={AlertCircle}
              title="Couldn't generate any questions"
              description="The passage may be too short or contain too few noun phrases the model can ask about. Try a different excerpt."
            />
          )}

          {result && result.questions.length > 0 && (
            <>
              <div className="flex items-center gap-2 text-[12px] text-muted">
                <span className="pill text-accent !border-accent/30">
                  {result.generated} / {result.requested} questions
                </span>
                <span className="pill">
                  <Clock size={11} />
                  {(result.latency_ms / 1000).toFixed(2)}s
                </span>
              </div>

              <div className="space-y-4 mt-2">
                {result.questions.map((q, i) => (
                  <QuizCard
                    key={i}
                    index={i}
                    total={result.questions.length}
                    item={q}
                  />
                ))}
              </div>
            </>
          )}
        </section>
      </div>
    </div>
  );
}
