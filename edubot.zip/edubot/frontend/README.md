# EdU BOT — Frontend (Next.js 14)

The chat UI for EdU BOT. Built with **Next.js 14 (App Router)**,
**TypeScript**, and **Tailwind CSS** — and a refined "warm academic"
aesthetic that pairs Instrument Serif headlines with Plus Jakarta Sans
body text.

## Quick start

```bash
cd frontend
npm install
copy .env.local.example .env.local       # Windows
# cp .env.local.example .env.local       # macOS / Linux
npm run dev
```

Open **http://localhost:3000**. The Next.js dev server proxies every
`/api/*` request to the FastAPI backend on port `8000` (configurable in
`.env.local`), so there's no CORS to worry about in dev.

## Folder layout

```
frontend/
├── app/
│   ├── layout.tsx           # Root layout — fonts + sidebar + providers
│   ├── globals.css          # Design tokens + glassmorphism utilities
│   ├── providers.tsx        # next-themes wrapper
│   ├── page.tsx             # Home (hero + 3 feature cards)
│   ├── qa/page.tsx          # Question Answering (chat style)
│   ├── summarize/page.tsx   # Summarization (form → card)
│   └── quiz/page.tsx        # Quiz Generation (form → reveal cards)
├── components/
│   ├── Sidebar.tsx          # Collapsible nav + history
│   ├── Logo.tsx             # Brand mark (SVG mortarboard)
│   ├── ThemeToggle.tsx      # Sun/moon swap
│   ├── MessageBubble.tsx    # Chat bubble used by QA
│   ├── SummaryCard.tsx      # Output card for the Summarize page
│   ├── QuizCard.tsx         # Interactive reveal-answer card
│   ├── LoadingIndicator.tsx # Typing dots + shimmer skeletons
│   ├── CopyButton.tsx       # Click-to-copy w/ check animation
│   └── EmptyState.tsx       # Pre-result empty hero
├── lib/
│   ├── api.ts               # Typed wrapper over /api/qa, /summarize, /quiz
│   ├── store.ts             # localStorage-backed chat history + hook
│   └── utils.ts             # cn() + small formatters
├── tailwind.config.ts
├── next.config.js           # /api/* proxy → FastAPI
└── package.json
```

## Aesthetic notes

* **Typography** — *Instrument Serif* (display) + *Plus Jakarta Sans*
  (body) + *JetBrains Mono* (numbers and quiz answers), all loaded
  through `next/font` so they're self-hosted and zero-flash.
* **Color** — driven by CSS variables in `globals.css`. Light mode is a
  warm "paper" cream; dark mode is an almost-black with the same teal
  accent. The amber gold appears on summary/quiz highlights.
* **Surface** — glassmorphism with `backdrop-blur` on the sidebar and
  message bubbles; refined opaque cards everywhere else so text stays
  crisp.
* **Motion** — soft fade-in-up on cards, staggered animation-delay on
  feature grids, typing-dot loaders, shimmer skeletons. Nothing flashy
  — just enough to make state changes feel deliberate.
