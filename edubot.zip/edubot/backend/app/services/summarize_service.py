"""
Summarization service.

Wraps the fine-tuned DistilBART checkpoint with the same generation
parameters used in the training notebook (4-beam search, early stopping)
and a tiny bit of pre/post-processing.
"""

from __future__ import annotations

import logging
import time

import torch

from app.models import ModelManager
from app.schemas import SummarizeResponse
from app.utils import clean_text

logger = logging.getLogger(__name__)

# Encoder input cap — matches `input_max_len=512` from the notebook.
_INPUT_MAX = 512


def summarize_text(
    text: str,
    max_length: int = 150,
    min_length: int = 40,
) -> SummarizeResponse:
    """Generate an abstractive summary of `text`."""
    t0 = time.perf_counter()

    mgr = ModelManager.get_instance()
    tokenizer, model, device = mgr.sum_tokenizer, mgr.sum_model, mgr.device

    text = clean_text(text)

    # Tokenise the article.
    enc = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=_INPUT_MAX,
    ).to(device)

    with torch.no_grad():
        ids = model.generate(
            **enc,
            max_length=max_length,
            min_length=min_length,
            num_beams=4,
            length_penalty=2.0,
            no_repeat_ngram_size=3,
            early_stopping=True,
        )

    summary = tokenizer.decode(ids[0], skip_special_tokens=True).strip()
    # Belt-and-braces: some BART variants emit a leading space.
    summary = clean_text(summary)

    orig_words = max(1, len(text.split()))
    summ_words = max(1, len(summary.split()))
    compression = round(summ_words / orig_words, 3)

    latency_ms = int((time.perf_counter() - t0) * 1000)
    logger.info(
        "SUM → %d→%d words (%.0f%%) in %dms",
        orig_words, summ_words, compression * 100, latency_ms,
    )

    return SummarizeResponse(
        summary=summary,
        original_length=orig_words,
        summary_length=summ_words,
        compression_ratio=compression,
        latency_ms=latency_ms,
    )
