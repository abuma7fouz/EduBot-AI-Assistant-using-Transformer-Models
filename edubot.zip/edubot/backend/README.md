# EdU BOT — Backend (FastAPI)

This is the inference server that wraps the three fine-tuned transformer
checkpoints produced by the notebooks in `notebooks/`.

## Endpoints

| Method | Path | Model | Purpose |
|--------|------|-------|---------|
| `POST` | `/api/qa`        | BERT      | Extractive question answering |
| `POST` | `/api/summarize` | DistilBART | Abstractive summarization |
| `POST` | `/api/quiz`      | T5         | Quiz / question generation |
| `GET`  | `/health`        | —          | Liveness + model status |
| `GET`  | `/docs`          | —          | Interactive OpenAPI playground |

## Quick start

```bash
# 1. From the project root, create + activate a virtualenv
python -m venv .venv
.venv\Scripts\activate          # Windows
# source .venv/bin/activate     # macOS / Linux

# 2. Install dependencies
cd backend
pip install -r requirements.txt

# 3. Configure model paths
copy .env.example .env          # Windows
# cp .env.example .env          # macOS / Linux
# …then edit .env if your models live somewhere else.

# 4. Run the server
python run.py
# or:   uvicorn app.main:app --reload --port 8000
```

The first request downloads two small NLTK resources (`punkt`,
`averaged_perceptron_tagger`) into your user cache — about 5 MB total.

## Folder layout

```
backend/
├── app/
│   ├── main.py            # FastAPI app + lifespan hook
│   ├── config.py          # pydantic-settings (.env reader)
│   ├── models/
│   │   └── ml_models.py   # Singleton: loads BERT/BART/T5 once
│   ├── schemas/
│   │   └── requests.py    # Request/response pydantic models
│   ├── routers/
│   │   ├── qa.py
│   │   ├── summarize.py
│   │   └── quiz.py
│   ├── services/          # Inference logic per task
│   │   ├── qa_service.py
│   │   ├── summarize_service.py
│   │   └── quiz_service.py
│   └── utils/
│       └── text_utils.py  # sentence split + answer-candidate mining
├── requirements.txt
├── .env.example
└── run.py
```

## Where do the models come from?

The two training notebooks save the fine-tuned checkpoints to:

```
models_lg/
├── qa_model/      ← BERT       (deepset/bert-base-uncased-squad2 base)
├── sum_model/     ← DistilBART (sshleifer/distilbart-cnn-12-6 base)
└── quiz_model/    ← T5         (valhalla/t5-base-qg-hl base)
```

The server reads `QA_MODEL_PATH`, `SUM_MODEL_PATH`, and `QUIZ_MODEL_PATH`
from `.env` (or env vars) and falls back to `../models_lg/<name>` if they
are unset. Paths can be absolute, which is the easiest fix on Windows:

```env
QA_MODEL_PATH=D:/My projects/NLP/EDU_BOT/Final Project/models_lg/qa_model
```

## Performance notes

* Models are loaded exactly once at startup (singleton + lifespan hook).
* On a CUDA GPU, FP16 is enabled automatically; turn it off with
  `USE_FP16=false` if your card doesn't support half-precision well.
* The quiz pipeline batches T5 generation (`batch_size=8`) so generating
  10 questions costs ~2 forward passes, not 10.
* All `model.generate(...)` calls run inside `torch.no_grad()` and the
  models are put in `.eval()` mode at load time.
