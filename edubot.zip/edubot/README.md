# EdU BOT 🎓

> **An educational AI assistant powered by three fine-tuned transformers.**
> Built by **TEAM ELMOLOK** for the NLP Final Project.

EdU BOT pairs a fast FastAPI inference backend with a polished
Next.js 14 chat UI to expose three complementary NLP capabilities
in one premium product:

1. **Question Answering** — fine-tuned `BERT-base-SQuAD2` (extractive)
2. **Summarization** — fine-tuned `DistilBART-CNN` (abstractive)
3. **Quiz Generation** — fine-tuned `T5-base-qg-hl` (generative)

---

## 1 · System overview

```
┌────────────────────────┐        ┌─────────────────────────────┐
│     Next.js 14 UI      │   HTTP │      FastAPI inference      │
│ (Tailwind + TS)        │ ──────►│ (BERT · DistilBART · T5)    │
│  - /qa  /summarize     │ ◄────  │  - /api/qa                  │
│  - /quiz  home page    │  JSON  │  - /api/summarize           │
│  - localStorage history│        │  - /api/quiz                │
└────────────────────────┘        └─────────────────────────────┘
            │                                  │
            └──────────  http://localhost:3000 ─┘
                                                ↓
                                  loads .pth weights from
                                       models_lg/
                                  ├── qa_model/     (BERT)
                                  ├── sum_model/    (DistilBART)
                                  └── quiz_model/   (T5)
```

The backend loads all three checkpoints **once** at startup (a thread-safe
singleton) and serves async endpoints. The frontend proxies `/api/*` to
the backend via `next.config.js`, so the browser never crosses origins
in development.

---

## 2 · Features implemented

| Feature | What you do | What you get |
|---|---|---|
| **Question Answering** | Paste a passage in the context panel, then chat your questions in. | An extracted answer, a confidence score, and the character offsets in the original passage. |
| **Summarization** | Paste an article. Tune `min_length` and `max_length` sliders. | A concise summary plus original word count, summary word count, compression %, and inference latency. |
| **Quiz Generation** | Paste educational text. Pick how many questions (1–15). | Interactive question cards with tap-to-reveal answers and the source sentence each question was derived from. |
| **Chat history** | Every generation is auto-saved. | The sidebar lists the most recent 50 items with timestamps; one click to clear. |
| **Dark / light mode** | Toggle in the sidebar footer. | Persists across reloads via `next-themes`. |
| **Collapsible sidebar** | Click the chevron. | Saves the collapse state to `localStorage`. |

---

## 3 · Technologies & tools

### Backend
* **FastAPI 0.115** — async, OpenAPI docs at `/docs` out of the box
* **PyTorch + Transformers 4.46** — same versions used by the training notebooks
* **Pydantic v2 / pydantic-settings** — typed config + request validation
* **NLTK** — POS-based answer-candidate mining for the quiz pipeline
* **Uvicorn** — ASGI server

### Frontend
* **Next.js 14 (App Router)** + **React 18**
* **TypeScript** in `strict` mode
* **Tailwind CSS 3.4** with a custom design-token system
* **next-themes** for dark/light switching
* **lucide-react** for icons
* `next/font` for self-hosted **Instrument Serif** + **Plus Jakarta Sans** + **JetBrains Mono**

---

## 4 · Folder structure

```
edubot/
├── README.md                        ← this file
├── .gitignore
│
├── backend/                         ← FastAPI inference server
│   ├── app/
│   │   ├── main.py                  ← app + lifespan model loading
│   │   ├── config.py                ← .env reader (pydantic-settings)
│   │   ├── models/
│   │   │   └── ml_models.py         ← ModelManager singleton (BERT/BART/T5)
│   │   ├── schemas/
│   │   │   └── requests.py          ← pydantic request/response models
│   │   ├── routers/
│   │   │   ├── qa.py
│   │   │   ├── summarize.py
│   │   │   └── quiz.py
│   │   ├── services/                ← actual inference code
│   │   │   ├── qa_service.py        ← BERT extractive QA + softmax confidence
│   │   │   ├── summarize_service.py ← DistilBART beam-4 generation
│   │   │   └── quiz_service.py      ← T5 batched <hl>-tag generation
│   │   └── utils/
│   │       └── text_utils.py        ← sentence split + noun-phrase mining
│   ├── requirements.txt
│   ├── .env.example
│   ├── run.py                       ← `python run.py` shortcut
│   └── README.md
│
├── frontend/                        ← Next.js 14 + Tailwind UI
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── globals.css              ← design tokens + utilities
│   │   ├── providers.tsx            ← next-themes wrapper
│   │   ├── page.tsx                 ← home (hero + feature cards)
│   │   ├── qa/page.tsx
│   │   ├── summarize/page.tsx
│   │   └── quiz/page.tsx
│   ├── components/
│   │   ├── Sidebar.tsx
│   │   ├── Logo.tsx
│   │   ├── ThemeToggle.tsx
│   │   ├── MessageBubble.tsx
│   │   ├── SummaryCard.tsx
│   │   ├── QuizCard.tsx
│   │   ├── LoadingIndicator.tsx
│   │   ├── CopyButton.tsx
│   │   └── EmptyState.tsx
│   ├── lib/
│   │   ├── api.ts                   ← typed wrapper over /api/*
│   │   ├── store.ts                 ← localStorage chat history + hook
│   │   └── utils.ts
│   ├── tailwind.config.ts
│   ├── tsconfig.json
│   ├── next.config.js
│   ├── postcss.config.js
│   ├── package.json
│   ├── .env.local.example
│   └── README.md
│
└── models_lg/                       ← (you bring this — from your notebooks)
    ├── qa_model/
    ├── sum_model/
    └── quiz_model/
```

---

## 5 · How the models are integrated

The two training notebooks save each fine-tuned model with
`model.save_pretrained(...)` and `tokenizer.save_pretrained(...)`. Place
those output folders side-by-side under `models_lg/` (matching the
screenshot you shared) and the backend will find them automatically:

```python
# backend/app/models/ml_models.py — abbreviated
self.qa_tokenizer, self.qa_model = self._load_one(
    "QA", settings.QA_MODEL_PATH, AutoModelForQuestionAnswering,
)
self.sum_tokenizer, self.sum_model = self._load_one(
    "Summarizer", settings.SUM_MODEL_PATH, AutoModelForSeq2SeqLM,
)
self.quiz_tokenizer, self.quiz_model = self._load_one(
    "Quiz", settings.QUIZ_MODEL_PATH, AutoModelForSeq2SeqLM,
)
```

Each service mirrors the inference code from the notebooks:

* **`qa_service.py`** runs the same tokenization (`max_length=384`,
  `truncation='only_second'`) as the notebook, then adds a softmax-based
  confidence score and recovers character offsets from
  `return_offsets_mapping`.

* **`summarize_service.py`** generates with the notebook's parameters
  (`num_beams=4`, `early_stopping=True`) plus a `length_penalty` and
  `no_repeat_ngram_size=3` to keep summaries crisp.

* **`quiz_service.py`** is the most involved. The T5 checkpoint expects
  inputs with `<hl> ... <hl>` around the answer span, so the service:

  1. Splits the passage into sentences with NLTK.
  2. POS-tags each sentence and extracts noun-phrases / numbers as
     candidate answers.
  3. Wraps each candidate in `<hl>` tags using the exact
     `make_qg_input` rule from the training notebook.
  4. Runs T5 in **batches of 8** with `num_beams=4`.
  5. De-duplicates resulting questions and stops at the requested count.

All three models run in `.eval()` mode under `torch.no_grad()`, and FP16
is enabled automatically on CUDA GPUs.

---

## 6 · How to run the project locally

### Prerequisites
* **Python 3.10 or 3.11**
* **Node.js 18+** and **npm**
* A CUDA-capable GPU is *recommended* but **not required** — the
  backend falls back to CPU automatically.
* Your three fine-tuned checkpoints in `models_lg/` (output of the
  training notebooks).

### Step 1 — Backend

```bash
cd backend

# Create + activate a virtual environment
python -m venv .venv
.venv\Scripts\activate                 # Windows
# source .venv/bin/activate            # macOS / Linux

# Install dependencies
pip install -r requirements.txt

# Copy and (optionally) edit the env file to point at your models
copy .env.example .env                 # Windows
# cp .env.example .env                 # macOS / Linux

# Start the server
python run.py
```

The server boots on **http://localhost:8000**.
Visit **http://localhost:8000/docs** for the interactive API explorer.

> 💡 If your `models_lg/` folder lives somewhere else (e.g. `D:\...`),
> edit `backend/.env` and set absolute paths — see the comments inside.

### Step 2 — Frontend

In a **second terminal**:

```bash
cd frontend
npm install
copy .env.local.example .env.local     # Windows
# cp .env.local.example .env.local     # macOS / Linux
npm run dev
```

Open **http://localhost:3000**.

That's it — start asking questions, summarizing articles, and
generating quizzes.

### Step 3 (optional) — Production build

```bash
# Frontend
cd frontend
npm run build
npm start                # serves on :3000

# Backend
cd backend
# (don't use --reload in production)
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1
```

> Use a **single worker** for the backend — model weights are loaded into
> process memory, and replicating them per worker would multiply RAM/VRAM
> usage. If you need more throughput, scale horizontally with a process
> manager (or expose `model.share_memory()` and use `--workers N`).

---

## 7 · API reference (cheat-sheet)

```http
POST /api/qa
{ "question": "When was the Eiffel Tower built?",
  "context":  "The Eiffel Tower is …" }

POST /api/summarize
{ "text": "Long article …",
  "max_length": 150, "min_length": 40 }

POST /api/quiz
{ "text": "Educational passage …",
  "num_questions": 5 }

GET  /health     → { status, version, team, models: { device, fp16, … } }
GET  /docs       → Swagger UI
```

---

## 8 · Credits

Built for the **EDU_BOT NLP Final Project** by **TEAM ELMOLOK**.

* Datasets — SQuAD (Rajpurkar et al.) · CNN / DailyMail (Hermann et al.)
* Base checkpoints — `deepset/bert-base-uncased-squad2`,
  `sshleifer/distilbart-cnn-12-6`, `valhalla/t5-base-qg-hl` from
  the Hugging Face Hub.
