"""
Light-weight NLP helpers used by the services.

The quiz pipeline needs to pick *answer spans* from a passage before
feeding them to the T5 question-generator, because the underlying
checkpoint (`valhalla/t5-base-qg-hl`) expects the answer to be wrapped
in `<hl> ... <hl>` highlight tags. We extract candidates with NLTK's
POS-tagger (good enough, no extra GB of model weights like spaCy).
"""

from __future__ import annotations

import logging
import re
from typing import List

import nltk

logger = logging.getLogger(__name__)


# ── NLTK resources ────────────────────────────────────────────────────
# Download lazily so the first request does the work and not the import.
_NLTK_READY = False


def _ensure_nltk() -> None:
    """Make sure punkt + averaged_perceptron_tagger are available."""
    global _NLTK_READY
    if _NLTK_READY:
        return

    resources = [
        ("tokenizers/punkt_tab", "punkt_tab"),
        ("tokenizers/punkt", "punkt"),
        ("taggers/averaged_perceptron_tagger_eng", "averaged_perceptron_tagger_eng"),
        ("taggers/averaged_perceptron_tagger", "averaged_perceptron_tagger"),
    ]
    for path, pkg in resources:
        try:
            nltk.data.find(path)
        except LookupError:
            try:
                nltk.download(pkg, quiet=True)
            except Exception as e:                           # noqa: BLE001
                logger.warning("Could not download NLTK resource %s: %s", pkg, e)
    _NLTK_READY = True


# ── Cleaning ──────────────────────────────────────────────────────────
def clean_text(text: str) -> str:
    """Collapse whitespace + strip — matches the notebook's preprocessing."""
    if not text:
        return ""
    return re.sub(r"\s+", " ", text).strip()


# ── Sentence splitting ────────────────────────────────────────────────
def split_sentences(text: str) -> List[str]:
    """
    Split into sentences using NLTK if available, otherwise a regex
    fallback that's good enough for English prose.
    """
    text = clean_text(text)
    if not text:
        return []

    _ensure_nltk()
    try:
        return [s.strip() for s in nltk.sent_tokenize(text) if s.strip()]
    except Exception as e:                                   # noqa: BLE001
        logger.warning("Falling back to regex sentence splitter: %s", e)
        # Split on .!? followed by whitespace + capital, but keep the
        # punctuation glued to the previous sentence.
        parts = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", text)
        return [p.strip() for p in parts if p.strip()]


# ── Answer-candidate extraction ───────────────────────────────────────
# NLTK POS-tag prefixes that we treat as "good answer words".
_NOUN_TAGS = ("NN", "NNS", "NNP", "NNPS")
_NUM_TAGS = ("CD",)                                          # numbers/years


def extract_answer_candidates(sentence: str, top_n: int = 3) -> List[str]:
    """
    Return up to `top_n` noun-phrase spans that look like good
    question-answer candidates.

    Strategy:
      • POS-tag the sentence.
      • Greedily merge adjacent nouns / proper nouns into phrases.
      • Also keep standalone numbers (years, dates, quantities) — they
        produce nice "When …?" / "How many …?" questions.
      • Sort by phrase length (longer ≈ more informative).
      • De-duplicate case-insensitively.
    """
    _ensure_nltk()
    sentence = clean_text(sentence)
    if not sentence:
        return []

    try:
        tokens = nltk.word_tokenize(sentence)
        tagged = nltk.pos_tag(tokens)
    except Exception as e:                                   # noqa: BLE001
        logger.warning("POS tagging failed (%s) — using regex fallback.", e)
        # Fallback: words that start with a capital letter (proper-ish nouns).
        cands = re.findall(r"\b[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*\b", sentence)
        return list(dict.fromkeys(cands))[:top_n]

    candidates: List[str] = []
    i = 0
    while i < len(tagged):
        word, tag = tagged[i]

        # Greedy noun-phrase merging.
        if tag.startswith(_NOUN_TAGS):
            phrase = [word]
            j = i + 1
            while j < len(tagged) and tagged[j][1].startswith(_NOUN_TAGS):
                phrase.append(tagged[j][0])
                j += 1
            text = " ".join(phrase)
            if len(text) > 2 and not text.lower() in {"the", "a", "an"}:
                candidates.append(text)
            i = j
            continue

        # Standalone numbers.
        if tag in _NUM_TAGS:
            candidates.append(word)

        i += 1

    # De-duplicate while preserving order, prefer longer phrases first.
    seen: set[str] = set()
    unique: List[str] = []
    for c in sorted(candidates, key=lambda s: -len(s)):
        key = c.lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(c)

    return unique[:top_n]
