/**
 * Lightweight chat-history store.
 *
 * Persists to `localStorage` so refreshes don't lose history. We use a
 * tiny pub-sub so multiple components on the same page see updates
 * without prop drilling — no Zustand / Redux needed.
 */

'use client';

import { useEffect, useState } from 'react';

export type FeatureKey = 'qa' | 'summarize' | 'quiz';

export interface ChatHistoryItem {
  id: string;
  feature: FeatureKey;
  /** Short label shown in the sidebar list. */
  title: string;
  /** Free-form payload that the feature page can rehydrate from. */
  data: unknown;
  createdAt: number;
}

const STORAGE_KEY = 'edubot.history.v1';
const listeners = new Set<() => void>();

function read(): ChatHistoryItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function write(items: ChatHistoryItem[]) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  listeners.forEach((l) => l());
}

export const history = {
  list(): ChatHistoryItem[] {
    return read().sort((a, b) => b.createdAt - a.createdAt);
  },

  add(item: Omit<ChatHistoryItem, 'id' | 'createdAt'>): ChatHistoryItem {
    const full: ChatHistoryItem = {
      ...item,
      id:
        (typeof crypto !== 'undefined' && 'randomUUID' in crypto
          ? crypto.randomUUID()
          : Math.random().toString(36).slice(2)),
      createdAt: Date.now(),
    };
    const next = [full, ...read()].slice(0, 50); // cap at 50 entries
    write(next);
    return full;
  },

  remove(id: string) {
    write(read().filter((i) => i.id !== id));
  },

  clear() {
    write([]);
  },

  get(id: string): ChatHistoryItem | undefined {
    return read().find((i) => i.id === id);
  },
};

/** React hook — re-renders the component when history changes. */
export function useChatHistory(filter?: FeatureKey) {
  const [items, setItems] = useState<ChatHistoryItem[]>([]);

  useEffect(() => {
    const refresh = () => {
      const list = history.list();
      setItems(filter ? list.filter((i) => i.feature === filter) : list);
    };
    refresh();
    listeners.add(refresh);
    return () => {
      listeners.delete(refresh);
    };
  }, [filter]);

  return items;
}
