import { ArrowRight, Clock, FileText, Sparkles } from 'lucide-react';

import { CopyButton } from './CopyButton';
import type { SummarizeResponse } from '@/lib/api';

interface Props {
  data: SummarizeResponse;
}

/**
 * Beautiful result card for the Summarize page.
 *
 * Layout: a big serif quotation-style summary up top, then a row of
 * "stat pills" — original length, summary length, compression ratio,
 * and latency — pulled from the API response.
 */
export function SummaryCard({ data }: Props) {
  const reduction = Math.max(0, Math.round((1 - data.compression_ratio) * 100));

  return (
    <article
      className="surface-card rounded-3xl p-7 md:p-8 animate-fade-in-up
                 shadow-[0_1px_3px_rgb(0_0_0_/_0.02),0_8px_24px_-6px_rgb(0_0_0_/_0.06)]"
    >
      <header className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2.5">
          <span className="grid place-items-center w-8 h-8 rounded-lg bg-gold/10 text-gold">
            <Sparkles size={15} />
          </span>
          <h3 className="font-display text-xl tracking-tight">Summary</h3>
        </div>
        <CopyButton text={data.summary} label="Copy" />
      </header>

      {/* The summary itself — slightly larger, serif accent for the
          opening glyph adds an editorial / quotation feel. */}
      <blockquote className="relative pl-5 border-l-2 border-accent/40">
        <p className="text-[15.5px] leading-[1.75] text-fg/90 whitespace-pre-wrap">
          {data.summary}
        </p>
      </blockquote>

      {/* Stats row */}
      <footer className="mt-6 pt-5 border-t border-border flex flex-wrap items-center gap-2">
        <span className="pill">
          <FileText size={11} />
          {data.original_length} words
        </span>
        <ArrowRight size={13} className="text-muted" />
        <span className="pill text-accent !border-accent/30">
          <FileText size={11} />
          {data.summary_length} words
        </span>
        <span className="pill">
          <span className="font-mono">{reduction}%</span> shorter
        </span>
        <span className="pill ml-auto">
          <Clock size={11} />
          {(data.latency_ms / 1000).toFixed(2)}s
        </span>
      </footer>
    </article>
  );
}
