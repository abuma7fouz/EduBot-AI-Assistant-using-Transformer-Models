import { LucideIcon } from 'lucide-react';
import { ReactNode } from 'react';

import { cn } from '@/lib/utils';

interface Props {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: ReactNode;
  className?: string;
}

export function EmptyState({ icon: Icon, title, description, action, className }: Props) {
  return (
    <div className={cn('flex flex-col items-center justify-center text-center py-16 px-6', className)}>
      <div
        className="relative grid place-items-center w-16 h-16 rounded-2xl
                   bg-gradient-to-br from-accent/10 to-gold/10
                   border border-border mb-5"
      >
        <Icon size={26} className="text-accent" />
        <span
          aria-hidden
          className="absolute inset-0 rounded-2xl bg-accent/5 blur-xl -z-10"
        />
      </div>
      <h3 className="font-display text-2xl tracking-tight text-fg mb-2">{title}</h3>
      <p className="text-sm text-muted max-w-md leading-relaxed">{description}</p>
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}
