import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Tiny helper to merge Tailwind class strings without duplicates.
 * Used everywhere: `cn('px-4 py-2', isActive && 'bg-accent')`.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Format a UNIX-ms timestamp as e.g. "2:35 PM" or "12 May, 2:35 PM". */
export function formatTime(ts: number): string {
  const d = new Date(ts);
  const sameDay = new Date().toDateString() === d.toDateString();
  return d.toLocaleString(undefined, {
    hour: 'numeric',
    minute: '2-digit',
    ...(sameDay ? {} : { day: 'numeric', month: 'short' }),
  });
}

/** Truncate a string for use in chat-history previews. */
export function truncate(text: string, n: number): string {
  if (text.length <= n) return text;
  return text.slice(0, n - 1).trimEnd() + '…';
}
