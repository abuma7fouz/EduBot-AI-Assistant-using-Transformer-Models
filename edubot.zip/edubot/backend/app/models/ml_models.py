"""
Singleton model loader.

The three fine-tuned checkpoints are large (≈ 100-500 MB each on disk and
several hundred MB resident once loaded onto a GPU). Loading them on every
request would be wasteful and slow, so we load them once at startup and
share the same `ModelManager` instance across all FastAPI routes.

The class is also thread-safe at construction time: even if multiple
worker threads call `get_instance()` simultaneously, only one set of
weights is loaded.
"""

from __future__ import annotations

import logging
import threading
from pathlib import Path
from typing import Optional

import torch
from transformers import (
    AutoModelForQuestionAnswering,
    AutoModelForSeq2SeqLM,
    AutoTokenizer,
)

from app.config import settings

logger = logging.getLogger(__name__)


class ModelManager:
    """Holds the three fine-tuned EdU BOT checkpoints + their tokenizers."""

    _instance: Optional["ModelManager"] = None
    _lock = threading.Lock()

    # Filled in by _load()
    device: torch.device
    use_fp16: bool

    qa_tokenizer = None
    qa_model = None

    sum_tokenizer = None
    sum_model = None

    quiz_tokenizer = None
    quiz_model = None

    # ────────────────────────────────────────────────────────────────
    # Singleton plumbing
    # ────────────────────────────────────────────────────────────────
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:                  # double-checked
                    inst = super().__new__(cls)
                    inst._initialized = False
                    cls._instance = inst
        return cls._instance

    @classmethod
    def get_instance(cls) -> "ModelManager":
        """Return the singleton, loading models on first call."""
        inst = cls()
        if not inst._initialized:
            inst._load()
        return inst

    # ────────────────────────────────────────────────────────────────
    # Loading
    # ────────────────────────────────────────────────────────────────
    def _resolve_device(self) -> torch.device:
        choice = settings.DEVICE.lower()
        if choice == "cpu":
            return torch.device("cpu")
        if choice == "cuda":
            if not torch.cuda.is_available():
                logger.warning("DEVICE=cuda but CUDA is not available; falling back to CPU.")
                return torch.device("cpu")
            return torch.device("cuda")
        # auto
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def _load_one(self, name: str, path_str: str, model_cls):
        """Load a single tokenizer + model pair from a directory."""
        path: Path = settings.resolve_path(path_str)
        if not path.exists():
            raise FileNotFoundError(
                f"[{name}] Could not find model directory: {path}\n"
                f"Make sure your fine-tuned checkpoint is saved there, "
                f"or update the corresponding *_MODEL_PATH in backend/.env"
            )

        logger.info("Loading %s from %s", name, path)
        tokenizer = AutoTokenizer.from_pretrained(str(path))
        model = model_cls.from_pretrained(str(path))

        # Move + dtype
        model = model.to(self.device)
        if self.use_fp16 and self.device.type == "cuda":
            model = model.half()
        model.eval()
        return tokenizer, model

    def _load(self) -> None:
        self.device = self._resolve_device()
        # FP16 only makes sense on GPU
        self.use_fp16 = settings.USE_FP16 and self.device.type == "cuda"
        logger.info(
            "Initialising ModelManager — device=%s, fp16=%s",
            self.device, self.use_fp16,
        )

        # The three models match what's saved by the training notebooks:
        #   QA   →  deepset/bert-base-uncased-squad2     (extractive QA)
        #   SUM  →  sshleifer/distilbart-cnn-12-6        (seq2seq)
        #   QUIZ →  valhalla/t5-base-qg-hl               (seq2seq, hl-tag)
        self.qa_tokenizer, self.qa_model = self._load_one(
            "QA",  settings.QA_MODEL_PATH,  AutoModelForQuestionAnswering,
        )
        self.sum_tokenizer, self.sum_model = self._load_one(
            "Summarizer", settings.SUM_MODEL_PATH, AutoModelForSeq2SeqLM,
        )
        self.quiz_tokenizer, self.quiz_model = self._load_one(
            "Quiz", settings.QUIZ_MODEL_PATH, AutoModelForSeq2SeqLM,
        )

        # Free any temporary memory allocator chunks.
        if self.device.type == "cuda":
            torch.cuda.empty_cache()

        self._initialized = True
        logger.info("✅ All three models loaded — ready to serve.")

    # ────────────────────────────────────────────────────────────────
    # Helpers exposed to services
    # ────────────────────────────────────────────────────────────────
    def status(self) -> dict:
        return {
            "device": str(self.device),
            "fp16": self.use_fp16,
            "qa_loaded": self.qa_model is not None,
            "sum_loaded": self.sum_model is not None,
            "quiz_loaded": self.quiz_model is not None,
        }
