import { cn } from '@/lib/utils';

interface Props {
  label?: string;
  className?: string;
  variant?: 'dots' | 'skeleton' | 'inline';
}

/**
 * Loading states used across the three feature pages.
 *  • dots     — small typing-style animation, for inline replies.
 *  • skeleton — shimmering placeholder card.
 *  • inline   — just three dots, no card wrapper.
 */
export function LoadingIndicator({ label = 'Thinking', variant = 'dots', className }: Props) {
  if (variant === 'inline') {
    return (
      <span className={cn('inline-flex gap-1.5 items-center', className)}>
        <span className="typing-dot" />
        <span className="typing-dot" />
        <span className="typing-dot" />
      </span>
    );
  }

  if (variant === 'skeleton') {
    return (
      <div className={cn('surface-card rounded-3xl p-6 space-y-3', className)}>
        <div className="shimmer h-3 w-1/2 rounded-full" />
        <div className="shimmer h-3 w-full rounded-full" />
        <div className="shimmer h-3 w-11/12 rounded-full" />
        <div className="shimmer h-3 w-9/12 rounded-full" />
        <div className="shimmer h-3 w-10/12 rounded-full" />
      </div>
    );
  }

  return (
    <div
      className={cn(
        'flex items-center gap-3 text-sm text-muted',
        'glass-card rounded-2xl px-4 py-3 w-fit',
        className,
      )}
    >
      <span className="inline-flex gap-1.5 items-center">
        <span className="typing-dot" />
        <span className="typing-dot" />
        <span className="typing-dot" />
      </span>
      <span className="text-fg/80">{label}</span>
      <span className="text-muted/70">— the model is generating…</span>
    </div>
  );
}
