'use client';

import { Moon, Sun } from 'lucide-react';
import { useTheme } from 'next-themes';
import { useEffect, useState } from 'react';

import { cn } from '@/lib/utils';

interface Props {
  className?: string;
  showLabel?: boolean;
}

export function ThemeToggle({ className, showLabel = false }: Props) {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  // next-themes can't know the chosen theme on the server, so we wait for
  // hydration before rendering the toggle to avoid flicker / mismatch.
  useEffect(() => setMounted(true), []);

  const isDark = theme === 'dark';
  const next = isDark ? 'light' : 'dark';

  return (
    <button
      type="button"
      aria-label={mounted ? `Switch to ${next} mode` : 'Toggle theme'}
      onClick={() => setTheme(next)}
      className={cn(
        'relative inline-flex items-center gap-2',
        'rounded-full px-3 py-2 text-sm font-medium',
        'transition-colors duration-200',
        'hover:bg-elevated',
        className,
      )}
    >
      <span className="relative w-4 h-4">
        <Sun
          className={cn(
            'absolute inset-0 transition-all duration-300',
            mounted && isDark ? 'opacity-0 rotate-90 scale-0' : 'opacity-100 rotate-0 scale-100',
          )}
          size={16}
        />
        <Moon
          className={cn(
            'absolute inset-0 transition-all duration-300',
            mounted && isDark ? 'opacity-100 rotate-0 scale-100' : 'opacity-0 -rotate-90 scale-0',
          )}
          size={16}
        />
      </span>
      {showLabel && <span>{isDark ? 'Light mode' : 'Dark mode'}</span>}
    </button>
  );
}
