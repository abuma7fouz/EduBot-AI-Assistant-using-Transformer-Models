'use client';

import {
  ChevronLeft,
  ChevronRight,
  FileText,
  Github,
  Home,
  MessageCircleQuestion,
  Sparkles,
  Trash2,
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';

import { Logo } from './Logo';
import { ThemeToggle } from './ThemeToggle';
import { history, useChatHistory, type FeatureKey } from '@/lib/store';
import { cn, formatTime, truncate } from '@/lib/utils';

interface NavItem {
  href: string;
  label: string;
  feature: FeatureKey | 'home';
  icon: typeof Home;
  description: string;
}

const NAV: NavItem[] = [
  { href: '/',          label: 'Home',      feature: 'home',      icon: Home,                    description: 'Overview' },
  { href: '/qa',        label: 'Q & A',     feature: 'qa',        icon: MessageCircleQuestion,   description: 'Ask about a passage' },
  { href: '/summarize', label: 'Summarize', feature: 'summarize', icon: FileText,                description: 'Condense long text' },
  { href: '/quiz',      label: 'Quiz',      feature: 'quiz',      icon: Sparkles,                description: 'Generate questions' },
];

export function Sidebar() {
  const pathname = usePathname();
  const items = useChatHistory();
  const [collapsed, setCollapsed] = useState(false);

  // Remember collapse state across reloads.
  useEffect(() => {
    const v = typeof window !== 'undefined' && localStorage.getItem('edubot.sidebar.collapsed');
    if (v === '1') setCollapsed(true);
  }, []);
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('edubot.sidebar.collapsed', collapsed ? '1' : '0');
    }
  }, [collapsed]);

  return (
    <aside
      className={cn(
        'relative flex flex-col h-screen shrink-0 transition-[width] duration-300',
        'border-r border-border bg-elevated/60 backdrop-blur-xl',
        collapsed ? 'w-[72px]' : 'w-[280px]',
      )}
    >
      {/* ── Header (brand) ───────────────────────────────────────── */}
      <div className="flex items-center justify-between px-4 py-5 shrink-0">
        <Logo collapsed={collapsed} />
        <button
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          onClick={() => setCollapsed((c) => !c)}
          className="hidden md:grid place-items-center w-7 h-7 rounded-md
                     hover:bg-surface text-muted hover:text-fg transition-colors"
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
      </div>

      {/* ── Primary nav ──────────────────────────────────────────── */}
      <nav className="px-3 space-y-1">
        {NAV.map(({ href, label, icon: Icon, description }) => {
          const active = pathname === href;
          return (
            <Link
              key={href}
              href={href}
              title={collapsed ? label : undefined}
              className={cn(
                'group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm',
                'transition-colors duration-200',
                active
                  ? 'bg-surface text-fg shadow-sm border border-border'
                  : 'text-muted hover:text-fg hover:bg-surface/70',
              )}
            >
              <Icon
                size={18}
                className={cn(
                  'shrink-0 transition-colors',
                  active ? 'text-accent' : 'text-muted group-hover:text-fg',
                )}
              />
              {!collapsed && (
                <span className="flex-1 flex flex-col leading-tight">
                  <span className="font-medium">{label}</span>
                  <span className="text-[11px] text-muted">{description}</span>
                </span>
              )}
              {active && !collapsed && (
                <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse-soft" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* ── History ──────────────────────────────────────────────── */}
      {!collapsed && (
        <div className="flex flex-col flex-1 min-h-0 mt-6">
          <div className="flex items-center justify-between px-5 mb-2">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted">
              Recent
            </h3>
            {items.length > 0 && (
              <button
                onClick={() => {
                  if (confirm('Clear all chat history?')) history.clear();
                }}
                className="text-muted hover:text-fg transition-colors"
                aria-label="Clear history"
              >
                <Trash2 size={13} />
              </button>
            )}
          </div>
          <div className="flex-1 overflow-y-auto px-3 pb-2">
            {items.length === 0 ? (
              <p className="text-xs text-muted px-2 py-3 leading-relaxed">
                Your generations will appear here. Try the
                <span className="text-fg"> Q&amp;A</span>,
                <span className="text-fg"> Summarize</span>, or
                <span className="text-fg"> Quiz </span>
                pages to get started.
              </p>
            ) : (
              <ul className="space-y-0.5">
                {items.map((it) => (
                  <li key={it.id}>
                    <Link
                      href={`/${it.feature}?h=${it.id}`}
                      className="group flex flex-col gap-0.5 rounded-lg px-3 py-2
                                 hover:bg-surface/70 transition-colors"
                    >
                      <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider">
                        <FeatureDot feature={it.feature} />
                        <span className="text-muted">{it.feature}</span>
                        <span className="text-muted/70 ml-auto">
                          {formatTime(it.createdAt)}
                        </span>
                      </div>
                      <span className="text-xs text-fg/90 line-clamp-2 leading-snug">
                        {truncate(it.title, 60)}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}

      {/* ── Footer ───────────────────────────────────────────────── */}
      <div
        className={cn(
          'border-t border-border mt-auto p-3 flex items-center',
          collapsed ? 'flex-col gap-2' : 'gap-2 justify-between',
        )}
      >
        <ThemeToggle showLabel={!collapsed} />
        {!collapsed && (
          <a
            href="https://github.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ghost text-muted hover:text-fg"
            title="Source"
          >
            <Github size={16} />
          </a>
        )}
      </div>
    </aside>
  );
}

/* ── Small helper: colored dot per feature ───────────────────────── */
function FeatureDot({ feature }: { feature: FeatureKey }) {
  const colors: Record<FeatureKey, string> = {
    qa: 'bg-accent',
    summarize: 'bg-gold',
    quiz: 'bg-emerald-400',
  };
  return <span className={cn('w-1.5 h-1.5 rounded-full', colors[feature])} />;
}
