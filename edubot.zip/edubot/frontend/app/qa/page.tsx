'use client';

import {
  AlertCircle,
  ChevronDown,
  Loader2,
  MessageCircleQuestion,
  RotateCcw,
  Send,
} from 'lucide-react';
import {
  FormEvent,
  KeyboardEvent,
  useEffect,
  useRef,
  useState,
} from 'react';

import { EmptyState } from '@/components/EmptyState';
import { LoadingIndicator } from '@/components/LoadingIndicator';
import { MessageBubble } from '@/components/MessageBubble';
import { api, type APIError, type QAResponse } from '@/lib/api';
import { history, useChatHistory } from '@/lib/store';
import { cn, truncate } from '@/lib/utils';

/* ── Demo defaults ──────────────────────────────────────────────── */
const DEMO_CONTEXT =
  "The Eiffel Tower is a wrought-iron lattice tower on the Champ de Mars in Paris, France. " +
  "It is named after the engineer Gustave Eiffel, whose company designed and built the tower. " +
  "Constructed from 1887 to 1889 as the entrance to the 1889 World's Fair, it was initially " +
  "criticised by some of France's leading artists and intellectuals for its design, but it has " +
  "become a global cultural icon of France and one of the most recognisable structures in the world.";

interface ChatMsg {
  id: string;
  role: 'user' | 'assistant' | 'error';
  text: string;
  meta?: QAResponse;
}

/* ─────────────────────────────────────────────────────────────────
   QA Page
   ─────────────────────────────────────────────────────────────── */
export default function QAPage() {
  const [context, setContext] = useState('');
  const [contextOpen, setContextOpen] = useState(true);
  const [question, setQuestion] = useState('');
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [loading, setLoading] = useState(false);

  const scrollerRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);

  // History sidebar bookkeeping (we just count for the header pill)
  const recent = useChatHistory('qa');

  // Auto-scroll to the latest message.
  useEffect(() => {
    const el = scrollerRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, [messages, loading]);

  // Auto-grow the question textarea.
  useEffect(() => {
    const el = taRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 160) + 'px';
  }, [question]);

  /* ── Submit handler ──────────────────────────────────────────── */
  async function onSubmit(e?: FormEvent) {
    e?.preventDefault();
    const q = question.trim();
    const c = context.trim();

    if (!c) {
      setMessages((m) => [
        ...m,
        {
          id: rid(),
          role: 'error',
          text: 'Please provide a context passage above before asking a question.',
        },
      ]);
      setContextOpen(true);
      return;
    }
    if (q.length < 3) return;

    const userMsg: ChatMsg = { id: rid(), role: 'user', text: q };
    setMessages((m) => [...m, userMsg]);
    setQuestion('');
    setLoading(true);

    try {
      const res = await api.qa(q, c);
      const reply: ChatMsg = {
        id: rid(),
        role: 'assistant',
        text: res.answer,
        meta: res,
      };
      setMessages((m) => [...m, reply]);

      // Save to history.
      history.add({
        feature: 'qa',
        title: `${truncate(q, 50)} — ${truncate(res.answer, 40)}`,
        data: { question: q, context: c, answer: res },
      });
    } catch (err) {
      const e = err as APIError;
      setMessages((m) => [
        ...m,
        { id: rid(), role: 'error', text: e.detail || 'Something went wrong.' },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function onKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    // Enter to send, Shift+Enter for newline.
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSubmit();
    }
  }

  function reset() {
    setMessages([]);
    setQuestion('');
  }

  /* ── Render ───────────────────────────────────────────────── */
  return (
    <div className="flex flex-col h-screen">
      {/* ── Page header ─────────────────────────────────────── */}
      <header className="shrink-0 border-b border-border bg-bg/70 backdrop-blur-xl">
        <div className="max-w-3xl mx-auto px-6 md:px-10 py-5 flex items-center gap-4">
          <span className="grid place-items-center w-9 h-9 rounded-xl bg-accent/10 text-accent">
            <MessageCircleQuestion size={18} />
          </span>
          <div className="flex-1 min-w-0">
            <h1 className="font-display text-2xl tracking-tight">Question Answering</h1>
            <p className="text-xs text-muted">
              Powered by fine-tuned <span className="font-mono">BERT-base-SQuAD2</span> ·
              extractive
            </p>
          </div>
          <span className="pill">{recent.length} saved</span>
          {messages.length > 0 && (
            <button
              onClick={reset}
              className="btn-ghost text-muted hover:text-fg"
              title="Clear conversation"
            >
              <RotateCcw size={14} />
              <span className="hidden md:inline">Reset</span>
            </button>
          )}
        </div>

        {/* ── Context panel ─────────────────────────────────── */}
        <div className="max-w-3xl mx-auto px-6 md:px-10 pb-5">
          <button
            onClick={() => setContextOpen((o) => !o)}
            className="flex items-center gap-2 text-[11px] uppercase
                       tracking-[0.16em] text-muted hover:text-fg
                       transition-colors mb-2"
            aria-expanded={contextOpen}
          >
            <ChevronDown
              size={13}
              className={cn('transition-transform', contextOpen && 'rotate-180')}
            />
            Context passage {context.trim() && `· ${context.trim().split(/\s+/).length} words`}
          </button>

          <div
            className={cn(
              'grid transition-[grid-template-rows] duration-300',
              contextOpen ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]',
            )}
          >
            <div className="overflow-hidden">
              <textarea
                value={context}
                onChange={(e) => setContext(e.target.value)}
                placeholder="Paste a passage here — the model will extract answers directly from it."
                className="input-field min-h-[110px] resize-y leading-relaxed"
                rows={4}
              />
              <div className="mt-2 flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setContext(DEMO_CONTEXT)}
                  className="text-[12px] text-accent hover:underline"
                >
                  Use demo passage
                </button>
                {context && (
                  <button
                    type="button"
                    onClick={() => setContext('')}
                    className="text-[12px] text-muted hover:text-fg"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* ── Scrolling messages area ─────────────────────────── */}
      <div ref={scrollerRef} className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-6 md:px-10 py-8">
          {messages.length === 0 && !loading && (
            <EmptyState
              icon={MessageCircleQuestion}
              title="Ask anything about the passage"
              description="Set the context above, then type a question below. The model returns the exact answer span along with a confidence score."
            />
          )}

          <div className="space-y-5">
            {messages.map((m) =>
              m.role === 'error' ? (
                <div
                  key={m.id}
                  className="flex items-start gap-3 text-[14px]
                             rounded-2xl border border-red-500/30
                             bg-red-500/5 text-red-400 px-4 py-3 animate-fade-in"
                >
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                  <span>{m.text}</span>
                </div>
              ) : (
                <MessageBubble
                  key={m.id}
                  role={m.role}
                  copyText={m.role === 'assistant' ? m.text : undefined}
                  footer={
                    m.meta && (
                      <div className="flex flex-wrap items-center gap-2 text-[11px]">
                        <span className="pill text-accent !border-accent/30">
                          Confidence · {(m.meta.confidence * 100).toFixed(1)}%
                        </span>
                        <span className="pill">
                          {m.meta.latency_ms} ms
                        </span>
                      </div>
                    )
                  }
                >
                  {m.text}
                </MessageBubble>
              ),
            )}

            {loading && (
              <div className="pl-11">
                <LoadingIndicator label="Reading the passage" />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── Question input dock ─────────────────────────────── */}
      <footer className="shrink-0 border-t border-border bg-bg/80 backdrop-blur-xl">
        <form onSubmit={onSubmit} className="max-w-3xl mx-auto px-6 md:px-10 py-4">
          <div
            className={cn(
              'flex items-end gap-2 rounded-3xl p-2 pl-5',
              'bg-surface border border-border',
              'focus-within:border-accent/60 focus-within:shadow-[0_0_0_3px_rgb(var(--accent)/0.10)]',
              'transition-all duration-200',
            )}
          >
            <textarea
              ref={taRef}
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              onKeyDown={onKeyDown}
              rows={1}
              placeholder="Ask a question about the passage…"
              className="flex-1 bg-transparent outline-none resize-none
                         text-[15px] py-2.5 placeholder:text-muted max-h-[160px]"
              disabled={loading}
            />
            <button
              type="submit"
              disabled={loading || !question.trim() || !context.trim()}
              className="btn-primary !rounded-2xl !px-4 !py-2.5 shrink-0"
              aria-label="Send question"
            >
              {loading ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <Send size={15} />
              )}
            </button>
          </div>
          <p className="mt-2 text-[11px] text-muted pl-5">
            Enter to send · Shift + Enter for a new line
          </p>
        </form>
      </footer>
    </div>
  );
}

/* tiny ID helper */
function rid() {
  return Math.random().toString(36).slice(2);
}
