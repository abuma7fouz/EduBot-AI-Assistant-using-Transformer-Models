"""EdU BOT — Educational AI assistant by TEAM ELMOLOK."""

__version__ = "1.0.0"
__team__ = "ELMOLOK"
