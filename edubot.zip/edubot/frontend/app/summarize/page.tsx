'use client';

import {
  AlertCircle,
  FileText,
  Loader2,
  Sparkles,
  Wand2,
} from 'lucide-react';
import { FormEvent, useState } from 'react';

import { EmptyState } from '@/components/EmptyState';
import { LoadingIndicator } from '@/components/LoadingIndicator';
import { SummaryCard } from '@/components/SummaryCard';
import { api, type APIError, type SummarizeResponse } from '@/lib/api';
import { history } from '@/lib/store';
import { truncate } from '@/lib/utils';

const DEMO =
  "The internet has transformed how we access and share information. " +
  "What began as a small network of research computers in the 1960s grew rapidly " +
  "after the invention of the World Wide Web in 1989, when Tim Berners-Lee proposed " +
  "a system of interlinked hypertext documents. Today, billions of people use the " +
  "internet daily for communication, education, commerce, and entertainment. The rise " +
  "of social media platforms has reshaped how news spreads and how people maintain " +
  "relationships, while the explosion of streaming services has changed the entertainment " +
  "industry forever. Cloud computing has allowed individuals and businesses to store and " +
  "process enormous amounts of data without owning physical servers, and artificial " +
  "intelligence is increasingly woven into the fabric of everyday online experiences — " +
  "from personalised search results to recommendation engines and chatbots. Despite these " +
  "advances, the internet has also raised serious concerns about privacy, misinformation, " +
  "and the digital divide between people with high-speed access and those without.";

export default function SummarizePage() {
  const [text, setText] = useState('');
  const [maxLen, setMaxLen] = useState(150);
  const [minLen, setMinLen] = useState(40);

  const [result, setResult] = useState<SummarizeResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const tooShort = words < 20;

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (tooShort) {
      setError('Please paste at least 20 words to summarize.');
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await api.summarize(text, { max_length: maxLen, min_length: minLen });
      setResult(res);
      history.add({
        feature: 'summarize',
        title: truncate(res.summary, 80),
        data: { text, ...res },
      });
    } catch (err) {
      setError((err as APIError).detail || 'Summarization failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-full">
      <div className="max-w-3xl mx-auto px-6 md:px-10 py-10 md:py-14">
        {/* ── Page header ──────────────────────────────────── */}
        <header className="mb-10 animate-fade-in">
          <div className="flex items-center gap-3 mb-3">
            <span className="grid place-items-center w-10 h-10 rounded-xl bg-gold/10 text-gold">
              <FileText size={18} />
            </span>
            <div>
              <h1 className="font-display text-3xl tracking-tight">Summarization</h1>
              <p className="text-xs text-muted">
                Powered by fine-tuned <span className="font-mono">DistilBART-CNN</span> ·
                abstractive
              </p>
            </div>
          </div>
          <p className="text-[15px] text-muted leading-relaxed max-w-2xl">
            Paste an article, lecture excerpt, or any long passage and EdU BOT will produce
            a faithful, concise summary. Use the length controls below to dial in how
            tight you want the result.
          </p>
        </header>

        {/* ── Input form ────────────────────────────────────── */}
        <form onSubmit={onSubmit} className="space-y-5 animate-fade-in-up">
          <div>
            <label className="flex items-center justify-between text-[11px] uppercase
                              tracking-[0.16em] text-muted mb-2">
              <span>Source text</span>
              <span className="font-mono">{words} words</span>
            </label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste a long passage to summarize…"
              className="input-field min-h-[220px] resize-y leading-relaxed"
              rows={10}
            />
            <div className="mt-2 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => setText(DEMO)}
                className="text-[12px] text-accent hover:underline"
              >
                Use demo article
              </button>
              {text && (
                <button
                  type="button"
                  onClick={() => setText('')}
                  className="text-[12px] text-muted hover:text-fg"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* ── Length controls ───────────────────────────── */}
          <div className="surface-card rounded-2xl p-5 grid grid-cols-1 sm:grid-cols-2 gap-5">
            <Slider
              label="Minimum length"
              value={minLen}
              min={10}
              max={200}
              step={5}
              onChange={(v) =>
                setMinLen(Math.min(v, maxLen - 10))
              }
            />
            <Slider
              label="Maximum length"
              value={maxLen}
              min={30}
              max={400}
              step={10}
              onChange={(v) =>
                setMaxLen(Math.max(v, minLen + 10))
              }
            />
          </div>

          {/* ── Submit ────────────────────────────────────── */}
          <div className="flex items-center justify-end gap-3">
            <button
              type="submit"
              disabled={loading || tooShort}
              className="btn-primary"
            >
              {loading ? (
                <>
                  <Loader2 size={15} className="animate-spin" />
                  Summarizing…
                </>
              ) : (
                <>
                  <Wand2 size={15} />
                  Generate summary
                </>
              )}
            </button>
          </div>
        </form>

        {/* ── Output ──────────────────────────────────────── */}
        <section className="mt-10 space-y-4" aria-live="polite">
          {error && (
            <div className="flex items-start gap-3 text-[14px]
                            rounded-2xl border border-red-500/30 bg-red-500/5
                            text-red-400 px-4 py-3 animate-fade-in">
              <AlertCircle size={16} className="shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {loading && <LoadingIndicator variant="skeleton" />}

          {!loading && !result && !error && (
            <EmptyState
              icon={Sparkles}
              title="No summary yet"
              description="Paste a passage above and hit Generate. The model returns the summary along with word counts, compression ratio, and inference latency."
            />
          )}

          {result && <SummaryCard data={result} />}
        </section>
      </div>
    </div>
  );
}

/* ─────────────────────── Slider sub-component ─────────────────────── */
function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between mb-2">
        <span className="text-[11px] uppercase tracking-[0.16em] text-muted">
          {label}
        </span>
        <span className="font-mono text-sm text-fg tabular-nums">{value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-accent"
      />
      <div className="mt-1 flex justify-between text-[10px] text-muted font-mono">
        <span>{min}</span>
        <span>{max}</span>
      </div>
    </div>
  );
}
