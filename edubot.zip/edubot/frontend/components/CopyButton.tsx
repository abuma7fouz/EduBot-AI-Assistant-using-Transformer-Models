'use client';

import { Check, Copy } from 'lucide-react';
import { useState } from 'react';

import { cn } from '@/lib/utils';

interface Props {
  text: string;
  className?: string;
  size?: number;
  label?: string;
}

export function CopyButton({ text, className, size = 14, label }: Props) {
  const [copied, setCopied] = useState(false);

  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        } catch {
          /* clipboard might be blocked in insecure contexts */
        }
      }}
      className={cn(
        'inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-xs',
        'text-muted hover:text-fg hover:bg-elevated transition-colors',
        className,
      )}
      aria-label="Copy to clipboard"
    >
      {copied ? (
        <Check size={size} className="text-accent" />
      ) : (
        <Copy size={size} />
      )}
      {label && <span>{copied ? 'Copied' : label}</span>}
    </button>
  );
}
