"""
Application configuration.

All settings are read from environment variables (or a local `.env` file
that sits next to this package). We use `pydantic-settings` so values are
typed, validated, and documented in one place.
"""

from pathlib import Path
from typing import List

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


# Project root = the folder that contains the "backend/" directory.
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    """Runtime configuration for the EdU BOT API."""

    # ── Model paths ────────────────────────────────────────────────────
    QA_MODEL_PATH: str = "../models_lg/qa_model"
    SUM_MODEL_PATH: str = "../models_lg/sum_model"
    QUIZ_MODEL_PATH: str = "../models_lg/quiz_model"

    # ── Server ─────────────────────────────────────────────────────────
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # ── CORS ───────────────────────────────────────────────────────────
    ALLOWED_ORIGINS: List[str] = Field(
        default_factory=lambda: [
            "http://localhost:3000",
            "http://127.0.0.1:3000",
        ]
    )

    # ── Inference ──────────────────────────────────────────────────────
    DEVICE: str = "auto"        # "auto" | "cuda" | "cpu"
    USE_FP16: bool = True       # half-precision on GPU

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @field_validator("ALLOWED_ORIGINS", mode="before")
    @classmethod
    def split_origins(cls, v):
        """Accept either a comma-separated string or a real list."""
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",") if origin.strip()]
        return v

    def resolve_path(self, raw: str) -> Path:
        """
        Resolve a model path. If the user passed a relative path it is
        interpreted relative to the project root (NOT cwd), so the server
        works no matter where it was launched from.
        """
        p = Path(raw)
        if not p.is_absolute():
            p = (PROJECT_ROOT / p).resolve()
        return p


# Singleton — import this everywhere.
settings = Settings()
