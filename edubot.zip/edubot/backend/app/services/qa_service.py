"""
Question-Answering service.

The fine-tuned BERT model is extractive — it predicts the start and end
positions of the answer span inside the context. This mirrors the
`get_answer()` function from `pipeline_BERT_DistilBART.ipynb` but adds:

  • A confidence score (soft-max-normalised joint probability of start+end)
  • The character offsets of the answer in the original context
  • Latency measurement
  • Defensive handling for impossible / empty answers
"""

from __future__ import annotations

import logging
import time

import torch
import torch.nn.functional as F

from app.models import ModelManager
from app.schemas import QAResponse
from app.utils import clean_text

logger = logging.getLogger(__name__)

# Hard limits that match the notebook training config.
_MAX_LEN = 384
_MAX_ANSWER_TOKENS = 30      # answers longer than this are almost always wrong


def answer_question(question: str, context: str) -> QAResponse:
    """Run the BERT QA model and return the best answer span."""
    t0 = time.perf_counter()

    mgr = ModelManager.get_instance()
    tokenizer, model, device = mgr.qa_tokenizer, mgr.qa_model, mgr.device

    question = clean_text(question)
    context = clean_text(context)

    # Tokenise — `return_offsets_mapping` lets us recover character spans.
    enc = tokenizer(
        question,
        context,
        return_tensors="pt",
        truncation="only_second",
        max_length=_MAX_LEN,
        return_offsets_mapping=True,
        padding=True,
    )
    offsets = enc.pop("offset_mapping")[0].tolist()
    seq_ids = enc.sequence_ids(0)

    enc = {k: v.to(device) for k, v in enc.items()}
    with torch.no_grad():
        out = model(**enc)

    start_logits = out.start_logits[0].float()
    end_logits = out.end_logits[0].float()

    # Disallow answers that fall outside the context part of the input,
    # are padding tokens, or are special tokens (sequence id != 1).
    mask = torch.tensor(
        [s == 1 for s in seq_ids],
        dtype=torch.bool,
        device=start_logits.device,
    )
    neg_inf = torch.finfo(start_logits.dtype).min
    start_logits = start_logits.masked_fill(~mask, neg_inf)
    end_logits = end_logits.masked_fill(~mask, neg_inf)

    # Find the best (start, end) pair where end ≥ start and length is sane.
    # We do this with the classic "outer-product of softmaxes" trick from
    # the original BERT paper — cheap because L is bounded by max_length.
    start_probs = F.softmax(start_logits, dim=-1)
    end_probs = F.softmax(end_logits, dim=-1)

    # Build score matrix and zero-out invalid pairs.
    scores = start_probs.unsqueeze(1) * end_probs.unsqueeze(0)       # [L, L]
    L = scores.size(0)
    # Upper-triangular + length-limited mask
    idx = torch.arange(L, device=scores.device)
    length_ok = (idx.unsqueeze(0) - idx.unsqueeze(1)).clamp(min=0) <= _MAX_ANSWER_TOKENS
    scores = scores * torch.triu(torch.ones_like(scores)) * length_ok

    flat = scores.view(-1).argmax()
    start_tok = (flat // L).item()
    end_tok = (flat % L).item()
    confidence = float(scores.view(-1)[flat].item())

    # Map back to character offsets in the *original* context.
    char_start, char_end = offsets[start_tok][0], offsets[end_tok][1]
    answer = context[char_start:char_end].strip()

    # Fallback for the (rare) empty answer case.
    if not answer:
        answer = "I couldn't find a confident answer in the provided context."
        confidence = 0.0

    latency_ms = int((time.perf_counter() - t0) * 1000)
    logger.info(
        "QA → answer=%r  confidence=%.3f  latency=%dms",
        answer[:60], confidence, latency_ms,
    )

    return QAResponse(
        answer=answer,
        confidence=round(confidence, 4),
        start=int(char_start),
        end=int(char_end),
        latency_ms=latency_ms,
    )
