import { Bot, User } from 'lucide-react';
import { ReactNode } from 'react';

import { CopyButton } from './CopyButton';
import { cn } from '@/lib/utils';

interface Props {
  role: 'user' | 'assistant';
  children: ReactNode;
  /** Plain-text version of the message for the copy button. */
  copyText?: string;
  /** Optional footer (e.g. confidence + latency for QA replies). */
  footer?: ReactNode;
  className?: string;
}

/**
 * Chat bubble used by the QA page. User messages sit on the right with a
 * tinted accent fill; assistant messages on the left with a glass surface.
 */
export function MessageBubble({ role, children, copyText, footer, className }: Props) {
  const isUser = role === 'user';

  return (
    <div
      className={cn(
        'flex gap-3 animate-fade-in-up',
        isUser ? 'flex-row-reverse' : 'flex-row',
        className,
      )}
    >
      {/* Avatar */}
      <div
        className={cn(
          'shrink-0 grid place-items-center w-8 h-8 rounded-full text-[11px] font-medium',
          isUser
            ? 'bg-accent text-bg'
            : 'bg-surface border border-border text-accent',
        )}
      >
        {isUser ? <User size={14} /> : <Bot size={14} />}
      </div>

      {/* Bubble */}
      <div
        className={cn(
          'group relative max-w-[78%] rounded-3xl px-5 py-3.5 text-[15px] leading-relaxed',
          isUser
            ? 'bg-accent/10 border border-accent/20 text-fg rounded-tr-md'
            : 'glass-card rounded-tl-md',
        )}
      >
        <div className="whitespace-pre-wrap">{children}</div>
        {footer && (
          <div className="mt-2 pt-2 border-t border-border/60 text-[11px] text-muted">
            {footer}
          </div>
        )}
        {copyText && !isUser && (
          <div className="absolute -bottom-3 left-3 opacity-0 group-hover:opacity-100 transition-opacity">
            <CopyButton text={copyText} className="bg-surface border border-border" />
          </div>
        )}
      </div>
    </div>
  );
}
