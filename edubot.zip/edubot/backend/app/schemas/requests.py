"""
Pydantic request/response schemas.

Keeping all of them in one file makes the API surface easy to scan and
keeps the OpenAPI docs (visit /docs) tidy.
"""

from typing import List, Optional

from pydantic import BaseModel, Field


# ───────────────────────── QA ─────────────────────────
class QARequest(BaseModel):
    question: str = Field(
        ..., min_length=3, max_length=500,
        description="The question to answer.",
        examples=["When was the Eiffel Tower built?"],
    )
    context: str = Field(
        ..., min_length=20, max_length=10_000,
        description="The passage that contains the answer (extractive QA).",
        examples=[
            "The Eiffel Tower is a wrought-iron lattice tower on the Champ "
            "de Mars in Paris, France. It was constructed from 1887 to 1889 "
            "as the entrance to the 1889 World's Fair."
        ],
    )


class QAResponse(BaseModel):
    answer: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    start: int = Field(..., description="Character offset of the answer in the context.")
    end: int
    latency_ms: int


# ─────────────────────── Summarize ───────────────────────
class SummarizeRequest(BaseModel):
    text: str = Field(
        ..., min_length=50, max_length=20_000,
        description="The article or long-form text to summarize.",
    )
    max_length: int = Field(
        150, ge=30, le=400,
        description="Approximate upper bound for the summary length (tokens).",
    )
    min_length: int = Field(
        40, ge=10, le=200,
        description="Approximate lower bound for the summary length (tokens).",
    )


class SummarizeResponse(BaseModel):
    summary: str
    original_length: int = Field(..., description="Word count of the input.")
    summary_length: int = Field(..., description="Word count of the summary.")
    compression_ratio: float
    latency_ms: int


# ───────────────────────── Quiz ─────────────────────────
class QuizRequest(BaseModel):
    text: str = Field(
        ..., min_length=80, max_length=20_000,
        description="Educational content to generate quiz questions from.",
    )
    num_questions: int = Field(
        5, ge=1, le=20,
        description="How many questions to generate.",
    )


class QuizItem(BaseModel):
    question: str
    answer: str
    context: str = Field(..., description="Sentence the question was derived from.")


class QuizResponse(BaseModel):
    questions: List[QuizItem]
    requested: int
    generated: int
    latency_ms: int


# ───────────────────────── Health ─────────────────────────
class HealthResponse(BaseModel):
    status: str
    version: str
    team: str
    models: Optional[dict] = None
