/**
 * Tiny typed wrapper around the FastAPI backend.
 *
 * All requests go through `/api/*` which Next.js proxies to the
 * backend (see `next.config.js`). That way the browser only ever
 * talks to its own origin and we sidestep CORS entirely in dev.
 */

// ───────────────── Types (mirror backend Pydantic schemas) ─────────────────
export interface QAResponse {
  answer: string;
  confidence: number;
  start: number;
  end: number;
  latency_ms: number;
}

export interface SummarizeResponse {
  summary: string;
  original_length: number;
  summary_length: number;
  compression_ratio: number;
  latency_ms: number;
}

export interface QuizItem {
  question: string;
  answer: string;
  context: string;
}

export interface QuizResponse {
  questions: QuizItem[];
  requested: number;
  generated: number;
  latency_ms: number;
}

export interface APIError {
  detail: string;
  status: number;
}

// ───────────────── Core fetch wrapper ─────────────────
async function postJSON<T>(path: string, body: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  } catch {
    // Network / CORS / server not running
    throw {
      detail:
        'Could not reach the EdU BOT backend. Is the FastAPI server running on port 8000?',
      status: 0,
    } as APIError;
  }

  if (!res.ok) {
    let detail = `${res.status} ${res.statusText}`;
    try {
      const j = await res.json();
      if (j?.detail) detail = typeof j.detail === 'string' ? j.detail : JSON.stringify(j.detail);
    } catch {
      /* body wasn't JSON */
    }
    throw { detail, status: res.status } as APIError;
  }

  return res.json() as Promise<T>;
}

// ───────────────── Public API ─────────────────
export const api = {
  qa: (question: string, context: string) =>
    postJSON<QAResponse>('/api/qa', { question, context }),

  summarize: (text: string, opts: { max_length?: number; min_length?: number } = {}) =>
    postJSON<SummarizeResponse>('/api/summarize', {
      text,
      max_length: opts.max_length ?? 150,
      min_length: opts.min_length ?? 40,
    }),

  quiz: (text: string, num_questions = 5) =>
    postJSON<QuizResponse>('/api/quiz', { text, num_questions }),

  health: async (): Promise<{ status: string; models?: Record<string, unknown> }> => {
    try {
      const res = await fetch('/api/../health').catch(() => fetch('/api/health'));
      if (!res.ok) throw new Error();
      return res.json();
    } catch {
      return { status: 'offline' };
    }
  },
};
