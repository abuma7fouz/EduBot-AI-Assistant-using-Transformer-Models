import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './lib/**/*.{ts,tsx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        // Distinctive academic feel: serif display + clean sans body.
        // Loaded via next/font in app/layout.tsx.
        display: ['var(--font-display)', 'Georgia', 'serif'],
        sans: ['var(--font-sans)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'ui-monospace', 'monospace'],
      },
      colors: {
        // Surface tokens are wired through CSS variables in globals.css
        // so they swap cleanly between dark and light.
        bg: 'rgb(var(--bg) / <alpha-value>)',
        surface: 'rgb(var(--surface) / <alpha-value>)',
        elevated: 'rgb(var(--elevated) / <alpha-value>)',
        border: 'rgb(var(--border) / <alpha-value>)',
        fg: 'rgb(var(--fg) / <alpha-value>)',
        muted: 'rgb(var(--muted) / <alpha-value>)',
        accent: 'rgb(var(--accent) / <alpha-value>)',
        'accent-soft': 'rgb(var(--accent-soft) / <alpha-value>)',
        gold: 'rgb(var(--gold) / <alpha-value>)',
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease-out',
        'fade-in-up': 'fadeInUp 0.5s ease-out both',
        'slide-in-right': 'slideInRight 0.3s ease-out',
        'pulse-soft': 'pulseSoft 2s ease-in-out infinite',
        'shimmer': 'shimmer 2.4s linear infinite',
        'blink': 'blink 1.2s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: { from: { opacity: '0' }, to: { opacity: '1' } },
        fadeInUp: {
          from: { opacity: '0', transform: 'translateY(8px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        slideInRight: {
          from: { opacity: '0', transform: 'translateX(12px)' },
          to: { opacity: '1', transform: 'translateX(0)' },
        },
        pulseSoft: { '0%, 100%': { opacity: '1' }, '50%': { opacity: '0.55' } },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        blink: { '0%, 100%': { opacity: '0.3' }, '50%': { opacity: '1' } },
      },
      backgroundImage: {
        'mesh-light':
          'radial-gradient(at 12% 8%, rgb(20 184 166 / 0.10) 0px, transparent 50%),' +
          'radial-gradient(at 88% 12%, rgb(217 119 6 / 0.08) 0px, transparent 55%),' +
          'radial-gradient(at 78% 92%, rgb(15 118 110 / 0.08) 0px, transparent 50%)',
        'mesh-dark':
          'radial-gradient(at 12% 8%, rgb(20 184 166 / 0.14) 0px, transparent 50%),' +
          'radial-gradient(at 88% 12%, rgb(217 119 6 / 0.10) 0px, transparent 55%),' +
          'radial-gradient(at 78% 92%, rgb(94 234 212 / 0.10) 0px, transparent 50%)',
      },
    },
  },
  plugins: [],
};

export default config;
