import {
  ArrowRight,
  FileText,
  MessageCircleQuestion,
  Sparkles,
} from 'lucide-react';
import Link from 'next/link';

import { cn } from '@/lib/utils';

/* ────────────────────────────────────────────────────────────────── */
/*  Hero + feature grid + meta.                                       */
/*  Static — no client state needed, so this stays a server component. */
/* ────────────────────────────────────────────────────────────────── */

const FEATURES = [
  {
    href: '/qa',
    icon: MessageCircleQuestion,
    title: 'Question Answering',
    desc: 'Drop a passage and ask precise questions. The fine-tuned BERT model finds the answer span in real time.',
    model: 'BERT',
    accent: 'text-accent',
    bg: 'from-accent/10 to-accent/0',
  },
  {
    href: '/summarize',
    icon: FileText,
    title: 'Summarization',
    desc: 'Condense long articles, lecture notes, or research excerpts into a tight, faithful overview.',
    model: 'DistilBART',
    accent: 'text-gold',
    bg: 'from-gold/12 to-gold/0',
  },
  {
    href: '/quiz',
    icon: Sparkles,
    title: 'Quiz Generation',
    desc: 'Turn any educational text into ready-to-study questions with revealed answers — perfect for review sessions.',
    model: 'T5',
    accent: 'text-emerald-400',
    bg: 'from-emerald-400/10 to-emerald-400/0',
  },
] as const;

export default function HomePage() {
  return (
    <div className="min-h-full">
      <div className="max-w-5xl mx-auto px-6 md:px-12 py-16 md:py-24">
        {/* ── Eyebrow ───────────────────────────────────────────── */}
        <div className="flex items-center gap-3 mb-8 animate-fade-in">
          <span
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full
                       text-[11px] uppercase tracking-[0.18em]
                       border border-accent/30 bg-accent/8 text-accent"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse-soft" />
            Team Elmolok · NLP Final Project
          </span>
        </div>

        {/* ── Hero ──────────────────────────────────────────────── */}
        <header className="mb-14 md:mb-20 animate-fade-in-up">
          <h1 className="font-display text-[clamp(48px,8vw,96px)] leading-[0.95] tracking-tight">
            Learn faster with
            <br />
            <span className="italic text-accent">three</span> models that
            <br />
            actually understand text.
          </h1>
          <p className="mt-7 text-lg text-muted max-w-2xl leading-relaxed">
            EdU BOT is an educational AI assistant built on three fine-tuned transformers —
            <span className="text-fg"> BERT</span> for extractive question answering,
            <span className="text-fg"> DistilBART</span> for summarization, and
            <span className="text-fg"> T5</span> for generating quizzes from any passage you give it.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/qa" className="btn-primary">
              Try Question Answering <ArrowRight size={15} />
            </Link>
            <Link href="/summarize" className="btn-ghost border border-border">
              Summarize a passage
            </Link>
          </div>
        </header>

        {/* ── Feature grid ──────────────────────────────────────── */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5">
          {FEATURES.map((f, i) => (
            <Link
              key={f.href}
              href={f.href}
              className={cn(
                'group relative overflow-hidden surface-card rounded-3xl p-6 md:p-7',
                'transition-all duration-300 animate-fade-in-up',
                'hover:-translate-y-1 hover:shadow-[0_20px_40px_-12px_rgb(0_0_0_/_0.18)]',
              )}
              style={{ animationDelay: `${120 + i * 90}ms` }}
            >
              {/* Background wash */}
              <span
                aria-hidden
                className={cn(
                  'absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-100',
                  'transition-opacity duration-500 -z-0',
                  f.bg,
                )}
              />

              <div className="relative z-10">
                <div className="flex items-start justify-between mb-5">
                  <span
                    className={cn(
                      'grid place-items-center w-11 h-11 rounded-xl border border-border bg-elevated',
                      f.accent,
                    )}
                  >
                    <f.icon size={20} />
                  </span>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-muted">
                    {f.model}
                  </span>
                </div>

                <h2 className="font-display text-2xl tracking-tight text-fg mb-2">
                  {f.title}
                </h2>
                <p className="text-[14px] text-muted leading-relaxed mb-5">
                  {f.desc}
                </p>

                <span
                  className={cn(
                    'inline-flex items-center gap-1.5 text-[13px] font-medium',
                    f.accent,
                    'transition-transform duration-300 group-hover:translate-x-0.5',
                  )}
                >
                  Open
                  <ArrowRight size={14} />
                </span>
              </div>
            </Link>
          ))}
        </section>

        {/* ── Meta strip ─────────────────────────────────────────── */}
        <section
          className="mt-16 md:mt-20 glass-card rounded-3xl p-7
                     grid grid-cols-1 sm:grid-cols-3 gap-6 animate-fade-in-up"
          style={{ animationDelay: '450ms' }}
        >
          <Stat label="Fine-tuned on" value="SQuAD + CNN/DailyMail" />
          <Stat label="Pipeline" value="FastAPI · PyTorch · Next.js" />
          <Stat label="Tasks served" value="QA · Summarize · Quiz" />
        </section>

        <p className="mt-10 text-xs text-muted">
          Built for the EDU_BOT NLP Final Project · TEAM ELMOLOK
        </p>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-[0.18em] text-muted mb-1.5">
        {label}
      </div>
      <div className="font-display text-xl tracking-tight">{value}</div>
    </div>
  );
}
